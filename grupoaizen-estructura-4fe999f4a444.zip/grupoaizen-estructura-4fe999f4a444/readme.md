# Estructura 2018
## Descripción

Este proyecto se hizo con la finalidad de agilizar el proceso de refrescar las vistas usando jade y sass.

## Código de Ejemplo

El código estará cuando clones el repositorio en gulpfile.js

## Motivación

No me gusta presionar F5 a cada rato si existen herramientas que refrescan

## Instalación


#### 1.- Clonamos el Repositorio
Usando el siguiente código:
```
git clone
```

#### 2.- Instalamos las dependiencias
Usando el siguiente código:
```
npm install
```
 
## Contributors

Brayan LP

## License

A short snippet describing the license (MIT)